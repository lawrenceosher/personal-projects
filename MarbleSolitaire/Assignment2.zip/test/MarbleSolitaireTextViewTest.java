import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Represents the test class of the MarbleSolitaireTextView class.
 */
public class MarbleSolitaireTextViewTest {

  private MarbleSolitaireView board1;

  private MarbleSolitaireView board2;

  private MarbleSolitaireView board3;

  private MarbleSolitaireModel game1;

  private MarbleSolitaireView board4;

  private MarbleSolitaireView board1V2;

  private MarbleSolitaireView board4V2;

  private Appendable app1;


  @Before
  public void initializer() {
    this.board1 = new MarbleSolitaireTextView(new EnglishSolitaireModel());
    this.board2 = new MarbleSolitaireTextView(new EnglishSolitaireModel(5));
    this.board3 = new MarbleSolitaireTextView(new EnglishSolitaireModel(5, 5, 4));
    this.game1 = new EnglishSolitaireModel();
    this.game1.move(1, 3, 3, 3);
    this.game1.move(4, 3, 2, 3);
    this.board4 = new MarbleSolitaireTextView(this.game1);

    this.app1 = new StringBuilder();
    this.board1V2 = new MarbleSolitaireTextView(new EnglishSolitaireModel(), this.app1);
    this.board4V2 = new MarbleSolitaireTextView(this.game1, this.app1);



  }

  @Test
  public void testConstructorException() {

    try {
      new MarbleSolitaireTextView(null);
      fail("Constructor did not throw IllegalArgumentException.");
    } catch (IllegalArgumentException e) {
      assertEquals("Provided model is null.", e.getMessage());
    }

  }

  @Test
  public void testToString() {

    assertEquals("    O O O\n" +
                          "    O O O\n" +
                          "O O O O O O O\n" +
                          "O O O _ O O O\n" +
                          "O O O O O O O\n" +
                          "    O O O\n" +
                          "    O O O", this.board1.toString());

    assertEquals("        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O _ O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O", this.board2.toString());

    assertEquals("        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O _ O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O", this.board3.toString());

    assertEquals("    O O O\n" +
                          "    O _ O\n" +
                          "O O O O O O O\n" +
                          "O O O _ O O O\n" +
                          "O O O _ O O O\n" +
                          "    O O O\n" +
                          "    O O O", this.board4.toString());

    this.game1.move(6, 3, 4, 3);
    this.board4 = new MarbleSolitaireTextView(this.game1);

    assertEquals("    O O O\n" +
                          "    O _ O\n" +
                          "O O O O O O O\n" +
                          "O O O _ O O O\n" +
                          "O O O O O O O\n" +
                          "    O _ O\n" +
                          "    O _ O", this.board4.toString());

  }

  @Test
  public void testConstructor2Exception() {

    try {
      new MarbleSolitaireTextView(new EnglishSolitaireModel(), null);
      fail("Constructor did not throw IllegalArgumentException.");
    } catch (IllegalArgumentException e) {
      assertEquals("Provided appendable is null.", e.getMessage());
    }

    try {
      new MarbleSolitaireTextView(null, null);
      fail("Constructor did not throw IllegalArgumentException.");
    } catch (IllegalArgumentException e) {
      assertEquals("Provided model is null.", e.getMessage());
    }

    try {
      new MarbleSolitaireTextView(null, new StringBuilder());
      fail("Constructor did not throw IllegalArgumentException.");
    } catch (IllegalArgumentException e) {
      assertEquals("Provided model is null.", e.getMessage());
    }

  }

  @Test
  public void testRenderBoardBeforeMoves() {

    try {
      this.board1V2.renderBoard();
    } catch (IOException e) {
      throw new IllegalStateException("Transmission to view failed.");
    }

    assertEquals("    O O O\n" +
                          "    O O O\n" +
                          "O O O O O O O\n" +
                          "O O O _ O O O\n" +
                          "O O O O O O O\n" +
                          "    O O O\n" +
                          "    O O O", this.app1.toString());

  }

  @Test
  public void testRenderBoardAfterMoves() {

    try {
      this.board4V2.renderBoard();
    } catch (IOException e) {
      throw new IllegalStateException("Transmission to view failed.");
    }

    assertEquals("    O O O\n" +
            "    O _ O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O _ O O O\n" +
            "    O O O\n" +
            "    O O O", this.app1.toString());

  }

  @Test
  public void testIOException() {

    Appendable fakeAppendable = new FakeTestAppendable();
    MarbleSolitaireView fakeBoard = new MarbleSolitaireTextView(new EnglishSolitaireModel(),
            fakeAppendable);

    try {
      fakeBoard.renderBoard();
      fail("Method did not throw IOException.");
    } catch (IOException e) {
      assertEquals("Transmission of the board to the data destination failed.",
              e.getMessage());
    }

    try {
      fakeBoard.renderMessage("hello");
      fail("Method did not throw IOException.");
    } catch (IOException e) {
      assertEquals("Transmission of the message to the data destination failed.",
              e.getMessage());
    }

  }

  @Test
  public void testRenderMessageOneMessage() {

    try {
      this.board4V2.renderMessage("Hello World.");
    } catch (IOException e) {
      throw new IllegalStateException("Transmission to view failed.");
    }

    assertEquals("Hello World.", this.app1.toString());


  }

  @Test
  public void testRenderMessageMultipleMessages() {

    try {
      this.board1V2.renderMessage("Example Message to be transmitted.");
    } catch (IOException e) {
      throw new IllegalStateException("Transmission to view failed.");
    }

    assertEquals("Example Message to be transmitted.", this.app1.toString());

    try {
      this.board1V2.renderMessage(" Additional message.");
    } catch (IOException e) {
      throw new IllegalStateException("Transmission to view failed.");
    }

    assertEquals("Example Message to be transmitted. Additional message.",
            this.app1.toString());


  }

  @Test
  public void testRenderMessageEmptyMessage() {

    try {
      this.board1V2.renderMessage("");
    } catch (IOException e) {
      throw new IllegalStateException("Transmission to view failed.");
    }

    assertEquals("", this.app1.toString());

  }



}



