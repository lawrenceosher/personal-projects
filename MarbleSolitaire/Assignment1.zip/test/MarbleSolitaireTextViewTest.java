import org.junit.Before;
import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Represents the test class of the MarbleSolitaireTextView class.
 */
public class MarbleSolitaireTextViewTest {

  MarbleSolitaireView board1;

  MarbleSolitaireView board2;

  MarbleSolitaireView board3;

  MarbleSolitaireModel game1;

  MarbleSolitaireView board4;

  @Before
  public void initializer() {
    this.board1 = new MarbleSolitaireTextView(new EnglishSolitaireModel());
    this.board2 = new MarbleSolitaireTextView(new EnglishSolitaireModel(5));
    this.board3 = new MarbleSolitaireTextView(new EnglishSolitaireModel(5, 5, 4));
    this.game1 = new EnglishSolitaireModel();
    this.game1.move(1, 3, 3, 3);
    this.game1.move(4, 3, 2, 3);
    this.board4 = new MarbleSolitaireTextView(this.game1);

  }

  @Test
  public void testConstructorException() {

    try {
      new MarbleSolitaireTextView(null);
      fail("Constructor did not throw IllegalArgumentException.");
    } catch (IllegalArgumentException e) {
      assertEquals("Provided model is null.", e.getMessage());
    }

  }

  @Test
  public void testToString() {

    assertEquals("    O O O\n" +
                          "    O O O\n" +
                          "O O O O O O O\n" +
                          "O O O _ O O O\n" +
                          "O O O O O O O\n" +
                          "    O O O\n" +
                          "    O O O", this.board1.toString());

    assertEquals("        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O _ O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O", this.board2.toString());

    assertEquals("        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O _ O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "O O O O O O O O O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O\n" +
                          "        O O O O O", this.board3.toString());

    assertEquals("    O O O\n" +
                          "    O _ O\n" +
                          "O O O O O O O\n" +
                          "O O O _ O O O\n" +
                          "O O O _ O O O\n" +
                          "    O O O\n" +
                          "    O O O", this.board4.toString());

    this.game1.move(6, 3, 4, 3);
    this.board4 = new MarbleSolitaireTextView(this.game1);

    assertEquals("    O O O\n" +
                          "    O _ O\n" +
                          "O O O O O O O\n" +
                          "O O O _ O O O\n" +
                          "O O O O O O O\n" +
                          "    O _ O\n" +
                          "    O _ O", this.board4.toString());

  }

}



